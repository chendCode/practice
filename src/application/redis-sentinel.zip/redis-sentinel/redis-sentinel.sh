#!/bin/sh

./bin/redis-server config/redis/redis-6380.conf 
echo "启动master 服务"
./bin/redis-sentinel config/sentinel/sentinel-26379.conf 
echo "启动master 哨兵"

./bin/redis-server config/redis/redis-16380.conf 
./bin/redis-sentinel config/sentinel/sentinel-26380.conf 


./bin/redis-server config/redis/redis-16381.conf 
./bin/redis-sentinel config/sentinel/sentinel-26381.conf 


echo "启动成功"
